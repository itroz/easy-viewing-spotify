=== Easy Viewing for Spotify ===
Contributors: (itroz)
Tags:  Spotify,elementor,playlist,Spotify Play Button, spotify Shortcode,easy spotify,widgets for elementor, Music, Spotify Embed, Embed Music, Spotify Widget, Embed content, Wordpress, Spotify for elementor,music widget, Spotify elementor,easy spotify shortcode, Embed, iframe, widget for elementor spotify
Stable tag: 1.2.1
Requires at least: 5.2
Tested up to: 6.4.0
Requires PHP: 7.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Easy viewing of Spotify audio files in WordPress through display in Gutenberg, Classic editors and Elementor.
Our goal is to provide easy and free use of the most used services in WordPress for you.
Easy Spotify plugin is the most used plugin provided by Itroz after Easy Soundcloud.

== Description ==

**Easy Viewing for Spotify Widget For Elementor** is the first use to goand easy to use [Elementor Page Builder](https://wordpress.org/plugins/elementor/) Spotify Widget. Our goal is to provide you with the Functional Elementor Widget That can be easly used, Add Spotify Music Without writing the Single Line of Code. Easy Viewing for Spotify helps users to use Spotify API on their websites easily without any headaches. If you like Liza Spotify Widget, Please review us on the wordpress.org as it will help us develop better Functionality for the Spotify Widget.



== Installation Plugin ==

1. Upload the plugin files to the `/wp-content/plugins/easy-viewing-spotify` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.


== How use! ==

You can use Easy Stopify Plugin on Gutenberg and Classic text boxes as well as Elementor.

Gutenberg and Classic text box:
To use it in the Gutenberg and Classic text box, just click on the Spotify icon and enter the desired address in it.

Elementor:
To use Elementor, search for Spotify in the widgets section and add it to your page.
